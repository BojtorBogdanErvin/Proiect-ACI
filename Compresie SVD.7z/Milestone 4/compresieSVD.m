function [imagineComprimata,Cr,MSE]=compresieSVD(denumireImagine,CrDorit)
    arguments(Input)
        denumireImagine (1,:) char
        CrDorit (1,1) double {mustBePositive,mustBeLessThanOrEqual(CrDorit,1)}=1
    end
    arguments(Output)
        imagineComprimata (:,:,3) uint8
        Cr (1,1) double
        MSE (1,1) double
    end
    imagine=imread(denumireImagine);
    [uR,sigmaR,vR]=svd(double(imagine(:,:,1)),'econ');
    [uG,sigmaG,vG]=svd(double(imagine(:,:,2)),'econ');
    [uB,sigmaB,vB]=svd(double(imagine(:,:,3)),'econ');
    [rangInitial,~]=size(sigmaR);
    %salveazaMatriciNecomprimat();
    gradDeCompresie=calculeazaGradDeCompresie();
    [uR,sigmaR,vR]=eliminaVSsiRedimensioneaza(uR,sigmaR,vR,gradDeCompresie);
    [uG,sigmaG,vG]=eliminaVSsiRedimensioneaza(uG,sigmaG,vG,gradDeCompresie);
    [uB,sigmaB,vB]=eliminaVSsiRedimensioneaza(uB,sigmaB,vB,gradDeCompresie);
    imagineComprimata=obtineImagineaComprimata(imagine,uR,sigmaR,vR,uG,sigmaG,vG,uB,sigmaB,vB);
    Cr=calculeazaCr();
    clear rangInitial;
    %salveazaMatriciComprimat();
    clear uR sigmaR vR uG sigmaG vG uB sigmaB vB;
    MSE=calculeazaMSE(imagine,imagineComprimata);
    
    function Cr=calculeazaCr
        Cr=numel(sigmaR)/rangInitial; % Ca sa fie subunitar
    end

    function salveazaMatriciNecomprimat
        denumireU=['U' denumireImagine(1:end-3) 'mat'];
        denumireSigma=['sigma' denumireImagine(1:end-3) 'mat'];
        denumireV=['V' denumireImagine(1:end-3) 'mat'];
        matrice=[uR uG uB];
        save(denumireU,'matrice');
        matrice=[sigmaR sigmaG sigmaB];
        save(denumireSigma,'matrice');
        matrice=[vR vG vB];
        save(denumireV,'matrice');
    end

    function salveazaMatriciComprimat
        denumireU=['Ucomprimat' denumireImagine(1:end-3) 'mat'];
        denumireSigma=['sigmaComprimat' denumireImagine(1:end-3) 'mat'];
        denumireV=['Vcomprimat' denumireImagine(1:end-3) 'mat'];
        matrice=[uR uG uB];
        save(denumireU,'matrice');
        matrice=[sigmaR sigmaG sigmaB];
        save(denumireSigma,'matrice');
        matrice=[vR vG vB];
        save(denumireV,'matrice');
    end

    function gradDeCompresie=calculeazaGradDeCompresie()
        gradDeCompresie = (1-CrDorit)*rangInitial;
    end

end

function[U,sigma,V]=eliminaVSsiRedimensioneaza(U,sigma,V,nrValoriSaFieSterse)
    arguments(Input)
        U
        sigma
        V
        nrValoriSaFieSterse (1,1) uint64 {valoareValida(nrValoriSaFieSterse,sigma)}
    end
    U=U(:,1:end-nrValoriSaFieSterse);
    %sigma=diag(sigma(1:end-nrValoriSaFieSterse,1:end-nrValoriSaFieSterse));
    sigma=diag(sigma);
    sigma=sigma(1:end-nrValoriSaFieSterse,1);
    V=V(:,1:end-nrValoriSaFieSterse);
end

function diagonalValidator(sigma)
    arguments
        sigma
    end
    %{
    [m,n]=size(sigma);
    for i=1:m
        for j=1:i-1
            if sigma(i,j)~=0
                error('Matricea nu este diagonala.');
            end
        end
        for j=i+1:n
            if sigma(i,j)~=0
                error('Matricea nu este diagonala.');
            end
        end
    end
    %}
end

function sigmaComprimatValidator(sigma)
arguments
    sigma
end
    for i=2:numel(sigma)
        if sigma(i)<=0
            error('Cel putin o valoare singulara este negativa sau nula.');
        elseif sigma(i-1)<sigma(i)
            error('Valorile singulare nu sunt descrescatoare.');
        end
    end
end

function valoareValida(nrValoriSaFieSterse,sigma)
arguments
    nrValoriSaFieSterse (1,1) uint16
    sigma
end
    [m,n]=size(sigma);
    m=min(m,n);
    for r=m:-1:1
        if sigma(r,r)~=0
            break;
        end
    end
    if nrValoriSaFieSterse >= r
        error('Numărul de valori singulare dorite a fi șterse (%u) este mai mare sau egal decât numărul de valori singulare din imagine (adică %u).',nrValoriSaFieSterse,length(sigma));
    end
end

function[imagineReconstruita]=obtineImagineaComprimata(image,uR,sigmaR,vR,uG,sigmaG,vG,uB,sigmaB,vB)
    arguments(Input)
        image uint8
        uR
        sigmaR
        vR
        uG
        sigmaG
        vG
        uB
        sigmaB
        vB
    end
    arguments(Output)
        imagineReconstruita uint8
    end
    [m,n,~]=size(double(image));
    imagineReconstruita=uint8(zeros(m,n,3));
    clear m n;    
    imagineReconstruita(:,:,1)=uint8(uR*diag(sigmaR)*vR');
    imagineReconstruita(:,:,2)=uint8(uG*diag(sigmaG)*vG');
    imagineReconstruita(:,:,3)=uint8(uB*diag(sigmaB)*vB');
end

function ret=calculeazaMSE(imagine,imagineComprimata)
arguments(Input)
    imagine(:,:,3) uint8
    imagineComprimata(:,:,3) uint8
end
    ret=sum(sum((imagine-imagineComprimata).^2))/numel(imagine);
    ret=(ret(1)+ret(2)+ret(3))/3;
end