function AnalizareAlgoritm()
    addpath(pwd);
    cd Imagini;
    delete('*.mat');
    imagefiles = dir('*.*');
    imagefiles=imagefiles(3:end);
    nfiles = length(imagefiles);
    A=zeros(nfiles,19);
    vector=0.1:0.05:1;
    lungimeVector=length(vector);
    parfor (i=1:nfiles,4)
        disp(imagefiles(i).name);
        for j=1:lungimeVector
            gradDeCompresie=(j+1)/20;
            [~,~,A(i,j)]=compresieSVD(imagefiles(i).name, gradDeCompresie);
        end
    end
    plot(vector,A);
    title('Analiză compresie');
    xlabel('Cr');
    ylabel('MSE');
    cd ..;
    fig=openfig('MSE(Cr).fig');
    data=fig.Children.Children;
    v=data(1).YData;
    for i=2:length(data)
        v=v+data(i).YData;
    end
    v=v/length(v);
    plot(data(1).XData,v);
    title('Caracteristica medie');
    xlabel('Cr');
    ylabel('MSE');
end