function [imagineComprimata,Cr,MSE]=compresieSVD(denumireImagine,gradDeCompresie)
    arguments(Input)
        denumireImagine (1,:) char
        gradDeCompresie (1,1) uint64=1
    end
    arguments(Output)
        imagineComprimata (:,:) uint8
        Cr (1,1) double
        MSE (1,1) double
    end

    imagine=imread(denumireImagine);
    imagine=rgb2gray(imagine);
    [U,sigma,V]=svd(double(imagine),'econ');
    save('U','U');
    save('sigma','sigma');
    save('V','V');
    eliminaVSsiRedimensioneaza();
    obtineImagineaComprimata();
    Cr=calculeazaCr();
    save('Ucomprimat','U');
    save('sigmaComprimat','sigma');
    save('Vcomprimat','V');
    clear U sigma V;
    MSE=calculeazaMSE();
    comparaDimensiuni();
    imshow([imagine imagineComprimata]);
    
    %{
    comparareDimensiuni();
    function comparareDimensiuni
        denumireImagineInitiala=strcat(strcat(denumireImagine(1:end-4),'_Original'),denumireImagine(end-3:end));
        denumireImagineComprimata=strcat(strcat(strcat(denumireImagine(1:end-4),'_Comprimat_'),string(gradDeCompresie)),denumireImagine(end-3:end));
        imwrite(imagine,denumireImagineInitiala);
        imwrite(imagineComprimata, denumireImagineComprimata);
        imagineOriginala=dir(denumireImagineInitiala);
        imagineComprimataFisier=dir(denumireImagineComprimata);
        clear denumireImagineInitiala denumireImagineComprimata;
        disp([imagineOriginala.bytes imagineComprimataFisier.bytes]);
        if imagineComprimataFisier.bytes > imagineOriginala.bytes
            disp("Comprimare esuata.");
        elseif imagineComprimataFisier.bytes == imagineOriginala.bytes
            disp("Necomprimat.");
        else
            disp("Comprimare reusita.");
        end
    end
    %}
    function eliminaVSsiRedimensioneaza
        sigma=diag(sigma);
        if gradDeCompresie>=length(sigma)
            error('Numărul de valori singulare dorite a fi șterse (%u) este mai mare sau egal decât numărul de valori singulare din imagine (adică %u).',gradDeCompresie,length(sigma));
        end
        U=U(:,1:end-gradDeCompresie);
        sigma=sigma(1:end-gradDeCompresie,1);
        V=V(:,1:end-gradDeCompresie);
    end
    function obtineImagineaComprimata
        r=numel(sigma);
        imagineComprimata=zeros(size(imagine));
        for i=1:r
            imagineComprimata=imagineComprimata+sigma(i,1)*U(:,i)*V(:,i)';
        end
        imagineComprimata=uint8(imagineComprimata);
    end
    function ret=calculeazaCr
        [m,n]=size(imagine);
        ret=m*n/(numel(sigma)*(m+n+1));
        if ret>100
            ret=99.9999;
        end
    end
    function ret=calculeazaMSE
        ret=sum(sum(transpose(imagine-imagineComprimata).^2))/numel(imagine);
    end
    function comparaDimensiuni
        U=[dir('U.mat').bytes dir('Ucomprimat.mat').bytes
            dir('sigma.mat').bytes dir('sigmaComprimat.mat').bytes
           dir('V.mat').bytes dir('Vcomprimat.mat').bytes];
        if U(1,1)>U(1,2) && U(2,1) > U(2,2) && U(3,1) > U(3,2)
            disp('Imaginea a fost comprimata');
        end
        disp(U);
    end
end